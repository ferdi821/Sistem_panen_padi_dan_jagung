

<?php $__env->startSection('title', 'Master Data Varietas & Komoditas - SIPANEN'); ?>

<?php $__env->startSection('content'); ?>
<style>
    #main-wrapper {
        min-height: auto !important;
    }
    main.flex-grow-1 {
        flex-grow: 0 !important;
    }
    /* Styling Pagination Bootstrap */
    .pagination {
        margin-bottom: 0;
    }
    .pagination .page-item .page-link {
        color: #106742;
        font-size: 12px;
        padding: 6px 12px;
        border-radius: 6px;
        margin: 0 2px;
    }
    .pagination .page-item.active .page-link {
        background-color: #106742;
        border-color: #106742;
        color: #fff;
    }
</style>

<div class="container-fluid px-4 py-3">

    <!-- HEADER HALAMAN -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
        <div>
            <h3 class="fw-bold mb-1" style="color: #106742;">Master Data Varietas & Komoditas</h3>
            <p class="text-muted small mb-0">Kelola data kode benih, komoditas, varietas, dan batas minimum stok.</p>
        </div>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'petugas_provinsi')): ?>
            <div>
                <button type="button" class="btn btn-success shadow-sm px-3 py-2" data-bs-toggle="modal" data-bs-target="#modalTambahBenih" style="background-color: #106742; border: none; font-size: 13px; font-weight: 600;">
                    + Tambah Varietas Baru
                </button>
            </div>
        <?php endif; ?>
    </div>

    <!-- NOTIFIKASI BERHASIL -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show mb-3" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- NOTIFIKASI ERROR -->
    <?php if(session('error') || $errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
            <?php if(session('error')): ?>
                <?php echo e(session('error')); ?>

            <?php else: ?>
                <ul class="mb-0 ps-3">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- TABEL BENIH -->
    <div class="card border-0 shadow-sm mb-3" style="border-radius: 12px; overflow: hidden;">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle text-center mb-0" style="font-size: 13px;">
                    <thead style="background-color: #f3f7f5; color: #315b49;">
                        <tr>
                            <th class="py-3">Kode</th>
                            <th class="text-start py-3">Nama Benih</th>
                            <th class="py-3">Komoditas</th>
                            <th class="py-3">Varietas</th>
                            <th class="py-3">Stok Min (Ton)</th>
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'petugas_provinsi')): ?>
                                <th class="py-3">Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $benihs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benih): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><code><?php echo e($benih->kode_benih); ?></code></td>
                                <td class="text-start fw-bold" style="color: #273b32;"><?php echo e($benih->nama_benih); ?></td>
                                <td>
                                    <?php if(strtolower($benih->komoditas) === 'padi'): ?>
                                        <span class="badge px-2 py-1" style="background-color: #d9f2e3; color: #106742; font-size: 10px; font-weight: 700;">PADI</span>
                                    <?php else: ?>
                                        <span class="badge px-2 py-1" style="background-color: #fff0c2; color: #956600; font-size: 10px; font-weight: 700;">JAGUNG</span>
                                    <?php endif; ?>
                                </td>
                                <td class="fw-bold"><?php echo e($benih->varietas); ?></td>
                                <td class="fw-bold text-dark"><?php echo e(number_format($benih->stok_minimum, 2)); ?> Ton</td>
                                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'petugas_provinsi')): ?>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-outline-warning px-2 py-1 me-1" data-bs-toggle="modal" data-bs-target="#modalEditBenih<?php echo e($benih->id); ?>" style="font-size: 11px; font-weight: 600;">
                                            Edit
                                        </button>

                                        <form action="<?php echo e(route('benih.destroy', $benih->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus varietas ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger px-2 py-1" style="font-size: 11px; font-weight: 600;">Hapus</button>
                                        </form>
                                    </td>
                                <?php endif; ?>
                            </tr>

                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'petugas_provinsi')): ?>
                                <!-- MODAL EDIT BENIH -->
                                <div class="modal fade" id="modalEditBenih<?php echo e($benih->id); ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
                                            <div class="modal-header text-white px-4 py-3" style="background-color: #e67e22;">
                                                <h5 class="modal-title fw-bold fs-6">Edit Data Varietas</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="<?php echo e(route('benih.update', $benih->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="modal-body p-4 text-start">
                                                    
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small" style="color: #34483e;">Kode Benih</label>
                                                        <input type="text" name="kode_benih" class="form-control form-control-sm" value="<?php echo e($benih->kode_benih); ?>" required>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small" style="color: #34483e;">Nama Benih</label>
                                                        <input type="text" name="nama_benih" class="form-control form-control-sm" value="<?php echo e($benih->nama_benih); ?>" required>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label class="form-label fw-bold small" style="color: #34483e;">Komoditas</label>
                                                            <select name="komoditas" class="form-select form-select-sm" required>
                                                                <option value="padi" <?php echo e(strtolower($benih->komoditas) == 'padi' ? 'selected' : ''); ?>>Padi</option>
                                                                <option value="jagung" <?php echo e(strtolower($benih->komoditas) == 'jagung' ? 'selected' : ''); ?>>Jagung</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label class="form-label fw-bold small" style="color: #34483e;">Varietas</label>
                                                            <input type="text" name="varietas" class="form-control form-control-sm" value="<?php echo e($benih->varietas); ?>" required>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold small" style="color: #34483e;">Stok Min Peringatan (Ton)</label>
                                                        <input type="number" step="0.01" min="0" name="stok_minimum" class="form-control form-control-sm" value="<?php echo e($benih->stok_minimum); ?>" required>
                                                    </div>

                                                </div>
                                                <div class="modal-footer border-0 pt-0 px-4 pb-4">
                                                    <button type="button" class="btn btn-secondary btn-sm px-3" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-warning btn-sm px-4 fw-bold text-white" style="background-color: #e67e22; border: none;">Simpan Perubahan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="<?php echo e(auth()->user()->hasRole('petugas_provinsi') ? 6 : 5); ?>" class="py-4 text-muted">Belum ada data master varietas benih.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- PAGINATION -->
    <?php if($benihs->hasPages()): ?>
        <div class="d-flex justify-content-center mt-3 mb-4">
            <?php echo e($benihs->links('pagination::bootstrap-5')); ?>

        </div>
    <?php endif; ?>

</div>

<?php if (\Illuminate\Support\Facades\Blade::check('role', 'petugas_provinsi')): ?>
    <!-- MODAL TAMBAH BENIH BARU -->
    <div class="modal fade" id="modalTambahBenih" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow" style="border-radius: 12px; overflow: hidden;">
                <div class="modal-header text-white px-4 py-3" style="background-color: #106742;">
                    <h5 class="modal-title fw-bold fs-6">Tambah Varietas Baru</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('benih.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body p-4 text-start">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold small" style="color: #34483e;">Kode Benih</label>
                            <input type="text" name="kode_benih" class="form-control form-control-sm" placeholder="Contoh: bnh-pdi-003" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small" style="color: #34483e;">Nama Benih</label>
                            <input type="text" name="nama_benih" class="form-control form-control-sm" placeholder="Contoh: Benih Padi Ciherang" required>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small" style="color: #34483e;">Komoditas</label>
                                <select name="komoditas" class="form-select form-select-sm" required>
                                    <option value="">-- Pilih Komoditas --</option>
                                    <option value="padi">Padi</option>
                                    <option value="jagung">Jagung</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small" style="color: #34483e;">Varietas</label>
                                <input type="text" name="varietas" class="form-control form-control-sm" placeholder="Contoh: Ciherang / Bisi" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small" style="color: #34483e;">Stok Min Peringatan (Ton)</label>
                            <input type="number" step="0.01" min="0" name="stok_minimum" class="form-control form-control-sm" placeholder="Contoh: 0.10" value="<?php echo e(old('stok_minimum', '0.10')); ?>" required>
                        </div>

                    </div>
                    <div class="modal-footer border-0 pt-0 px-4 pb-4">
                        <button type="button" class="btn btn-secondary btn-sm px-3" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success btn-sm px-4 fw-bold" style="background-color: #106742; border: none;">Simpan Varietas</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Sistem-Panen-Padi-dan-Jagung-Nasional\resources\views/benih/index.blade.php ENDPATH**/ ?>