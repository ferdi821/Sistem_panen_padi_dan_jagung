<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('kabupatens', function (Blueprint $table) {
            $table->id();
            $table->foreignId('provinsi_id')->constrained('provinsis')->onDelete('cascade');
            $table->string('kode_kabupaten')->unique();
            $table->string('nama_kabupaten'); // Contoh: Kabupaten Bandung, Kota Jambi, dll.
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kabupatens');
    }
};